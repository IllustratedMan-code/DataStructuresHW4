#ifndef errors_H
#define errors_H

class invalidIndexError{

};

#endif
